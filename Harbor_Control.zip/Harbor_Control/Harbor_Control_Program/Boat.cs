﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Harbor_Control_Program
{
    abstract class Boat
    {
        public abstract double calculateBoatSpeed(double distance);
    }
}
