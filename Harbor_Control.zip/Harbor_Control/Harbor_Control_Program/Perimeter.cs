﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace Harbor_Control_Program
{
    class Perimeter
    {
        private static int BoatDistance = 10; // 10 km permiter
     
        private static double boatTime;
        private const int Cargoboat = 1;
        private const int Sailboat = 2;
        private const int Speedboat = 3;
        static void Main(string[] args)
        {
            Perimeter perimeter = new Perimeter();
            Random random = new Random();

            for (int i = 0; i < 25; i++) // I used less than 25 iterations to illustrate if there were 24 hours.
            {
                int sailingboat = random.Next(4);
                perimeter.sailThroughPerimeter(sailingboat);
            }
            
            Console.Read();
        }

        public void sailThroughPerimeter(int boatID)
        {
           if(boatID.Equals(Cargoboat))
            {
                Cargoboat cargoBoat = new Cargoboat();
         
                boatTime = cargoBoat.calculateBoatSpeed(BoatDistance);
                boatSailing("Cargo boat");
                setBoatTimer(boatTime);

                nextBoat();

            }
            else if(boatID.Equals(Sailboat))
            {
                Sailboat sailBoat = new Sailboat();
                boatTime = sailBoat.calculateBoatSpeed(BoatDistance);
                boatSailing("sail boat");
                setBoatTimer(boatTime);

                nextBoat();

            }
            else if(boatID.Equals(Speedboat))
            {
                Speedboat speedBoat = new Speedboat();
                var boatTime = speedBoat.calculateBoatSpeed(BoatDistance);
                boatSailing("Speed boat");
                setBoatTimer(boatTime);
                nextBoat();

            }
            else
            {
                Console.WriteLine("Waiting for boat");

            }
            
        }

        private static void setBoatTimer(double boatTime)
        {
            int pause = Convert.ToInt32(boatTime) * 10000; //10000 is just the number of seconds. 10 seconds
            System.Threading.Thread.Sleep(pause);

        }

        private static void boatSailing(string boatType)
        {
            Console.WriteLine(boatType  + " Sailing");
            
        }

        private static void nextBoat()
        {
            Console.WriteLine("Next boat");

        }
    }
}
