﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Harbor_Control_Program
{
    class Sailboat : Boat
    {
        public double boatTime { get; set; }
        public double boatSpeed = 15;

        public int boatID { get; set; }
        public override double calculateBoatSpeed(double distance)
        {
            boatTime = distance / this.boatSpeed;
            return boatTime;
        }
    }
}
